package monster;

import java.sql.SQLException;

import entity.Entity;
import main.GamePanel;
//import object.OBJ_Coin_Bronze;
//import object.OBJ_Heart;
//import object.OBJ_ManaCrystal;
//import object.OBJ_Rock;

//import java.util.Random;

public class MON_GreenSlime extends Entity {
    GamePanel gp; // cuz of different package
    public MON_GreenSlime(GamePanel gp) {       
    	super(gp);

        this.gp = gp;

//        dieta;
//        comportamientos;
        
        hunger = maxHunger;
        maxHunger = 100;
        thirst = maxThirst;
        maxThirst = 100;
        
        type = type_monster;
        name = "Green Slime";
        defaultSpeed = 1;
        speed = defaultSpeed;
        maxLife = 4;
        life = maxLife;
        attack = 2;
        defense = 1;
        
        diet = gp.keyH.form1.diet;
		System.out.println("Dieta: " + diet + ".");
        
        behaviors = gp.dbManager.getBehaviorsBySpeciesId(1);
		for(int i = 0; i < behaviors.length; i++)
		{
			System.out.println("Registros realizado correctamente:" + behaviors[i] + ".");
		}
        
//        exp = 2;
        //projectile = new OBJ_Rock(gp);

        solidArea.x = 3;
        solidArea.y = 18;
        solidArea.width = 42;
        solidArea.height = 30;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        
        getImage();
    }

    public void getImage()
    {
        up1 = setup("/monster/greenslime_down_1",gp.tileSize,gp.tileSize);
        up2 = setup("/monster/greenslime_down_2",gp.tileSize,gp.tileSize);
        down1 = setup("/monster/greenslime_down_1",gp.tileSize,gp.tileSize);
        down2 = setup("/monster/greenslime_down_2",gp.tileSize,gp.tileSize);
        left1 = setup("/monster/greenslime_down_1",gp.tileSize,gp.tileSize);
        left2 = setup("/monster/greenslime_down_2",gp.tileSize,gp.tileSize);
        right1 = setup("/monster/greenslime_down_1",gp.tileSize,gp.tileSize);
        right2 = setup("/monster/greenslime_down_2",gp.tileSize,gp.tileSize);
    }
    
//    public void setAction()
//    {    	
//        if(active)
//        {
//            if(goalCol == -1 && goalRow == -1)
//            {
//                int[] pos = getRandomEmptyPosition(0);
//                goalCol = pos[0];
//                goalRow = pos[1];
//            }
//            else
//            {
//                if((worldX / gp.tileSize) == goalCol && (worldY / gp.tileSize) == goalRow)
//                {
//                    int[] pos = getRandomEmptyPosition(0); 
//                    goalCol = pos[0];
//                    goalRow = pos[1];
//                }
//                else
//                {
//                    if (goalCol >= 0 && goalCol < 50 && goalRow >= 0 && goalRow < 50) {
//                        searchPath(goalCol, goalRow);
//                    } else {
//                        int[] pos = getRandomEmptyPosition(0);
//                        goalCol = pos[0];
//                        goalRow = pos[1];
//                    }
//                }
//            }
//        }
//    }
    
    public void setAction()
    {    	
        if (active)
        {
            if (goalCol == -1 && goalRow == -1)
            {
                int[] pos = getRandomEmptyPosition(0); 
                goalCol = pos[0];
                goalRow = pos[1];
            }
            else
            {
                int currentCol = worldX / gp.tileSize;
                int currentRow = worldY / gp.tileSize;

                if (currentCol == goalCol && currentRow == goalRow)
                {
                    int[] pos = getRandomEmptyPosition(0); 
                    goalCol = pos[0];
                    goalRow = pos[1];
                }
            }
            
            if (goalCol >= 0 && goalCol < 50 && goalRow >= 0 && goalRow < 50) {
                searchPath(goalCol, goalRow);
            } else {
                int[] pos = getRandomEmptyPosition(0); 
                goalCol = pos[0];
                goalRow = pos[1];
            }
        }
    }

//    public void damageReaction() {
//        actionLockCounter = 0;
//        //direction = gp.player.direction;
//        onPath = true; // gets aggro
//    }
//    public void checkDrop()
//    {
//        //CAST A DIE
//        int i = new Random().nextInt(100)+1;
//
//        //SET THE MONSTER DROP
//        if(i < 50)
//        {
//            dropItem(new OBJ_Coin_Bronze(gp));
//        }
//        if(i >= 50 && i < 75)
//        {
//            dropItem(new OBJ_Heart(gp));
//        }
//        if(i >= 75 && i < 100)
//        {
//            dropItem(new OBJ_ManaCrystal(gp));
//        }
//    }
}
