package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;

import entity.Entity;
//import data.Progress;
//import entity.NPC_BigRock;
//import entity.NPC_Merchant;
//import entity.NPC_OldMan;
import monster.*;
import object.*;
//import tile_interactive.IT_DestructibleWall;
//import tile_interactive.IT_DryTree;
//import tile_interactive.IT_MetalPlate;

public class AssetSetter {

    GamePanel gp;
    Timer timer;
    int interval = 120;
    
    Random rnum = new Random();
    
    int minAmmount = rnum.nextInt(5) + 5;
    int maxAmmount = rnum.nextInt(5) + 1;
    
    public ArrayList<Integer> puntosInteresMapa0X = new ArrayList<>();
    public ArrayList<Integer> puntosInteresMapa0Y = new ArrayList<>();
    
    public boolean isPositionOccupied(int mapNum, int x, int y) 
    {
        for (int i = 0; i < gp.obj[mapNum].length; i++)
        {
            if (gp.obj[mapNum][i] != null && gp.obj[mapNum][i].worldX == x && gp.obj[mapNum][i].worldY == y) 
            {
                return true;
            }
        }
        
        return false;
    }
    
    public int[] getRandomEmptyPosition(int mapNum)
    {
        int x, y;
        
        do 
        {
            x = gp.tileSize * puntosInteresMapa0X.get(gp.rnum.nextInt(9) + 1);
            y = gp.tileSize * puntosInteresMapa0Y.get(gp.rnum.nextInt(11) + 1);
        } while (isPositionOccupied(mapNum, x, y));
        
        return new int[]{x, y};
    }

//    public int[] getValidSpawnPosition(Entity entity, int mapNum, int startX, int startY) 
//    {
//        int[][] directions = 
//        {
//            {0, -gp.tileSize},   // Arriba
//            {0, gp.tileSize},    // Abajo
//            {-gp.tileSize, 0},   // Izquierda
//            {gp.tileSize, 0}     // Derecha
//        };
//
//        while (true) {
//            for (int[] direction : directions)
//            {
//                int newX = startX + direction[0];
//                int newY = startY + direction[1];
//
//                // Colocamos temporalmente al monstruo en la nueva posición para verificar colisiones
//                entity.worldX = newX;
//                entity.worldY = newY;
//                entity.solidArea.x = newX + entity.solidAreaDefaultX;
//                entity.solidArea.y = newY + entity.solidAreaDefaultY;
//
//                // Reseteamos la bandera de colisión
//                entity.collisionOn = false;
//
//                // Verificamos que las coordenadas estén dentro de los límites antes de llamar a checkTile
//                if (newX >= 0 && newX < gp.tileM.mapTileNum[mapNum].length * gp.tileSize &&
//                    newY >= 0 && newY < gp.tileM.mapTileNum[mapNum][0].length * gp.tileSize) 
//                {
//
//                    // Verificamos colisiones con tiles
//                    gp.cChecker.checkTile(entity);
//
//                    // Verificamos colisiones con otros monstruos
//                    if (!entity.collisionOn) 
//                    {
//                        int collisionIndex = gp.cChecker.checkEntity(entity, gp.monster);
//                        
//                        if (collisionIndex == 999) 
//                        {
//                            return new int[]{newX, newY}; // No colisión
//                        }
//                    }
//                }
//            }
//
//            // Actualizamos el temporizador interno y verificamos si se dispara para evitar bucles infinitos
//            gp.timer.update();
//            if (gp.timer.isTriggered()) 
//            {
//                // Si el temporizador se dispara, devolvemos una posición inválida o hacemos alguna otra acción
//                return new int[]{-1, -1}; // Puedes cambiar esto según tus necesidades
//            }
//        }
//    }

    
    public void map0PointsX()
    {
    	puntosInteresMapa0X.add(13);		// 0
    	puntosInteresMapa0X.add(15);		// 1
    	puntosInteresMapa0X.add(20);		// 2
    	puntosInteresMapa0X.add(22);		// 3
    	puntosInteresMapa0X.add(24);		// 4
    	puntosInteresMapa0X.add(25);		// 5
    	puntosInteresMapa0X.add(27);		// 6
    	puntosInteresMapa0X.add(29);		// 7
    	puntosInteresMapa0X.add(34);		// 8
    	puntosInteresMapa0X.add(36);		// 9
    }
    
    public void map0PointsY()
    {
    	puntosInteresMapa0Y.add(8)	;		// 0
    	puntosInteresMapa0Y.add(11);		// 1
    	puntosInteresMapa0Y.add(14);		// 2
    	puntosInteresMapa0Y.add(17);		// 3
    	puntosInteresMapa0Y.add(20);		// 4
    	puntosInteresMapa0Y.add(23);		// 5
    	puntosInteresMapa0Y.add(26);		// 6
    	puntosInteresMapa0Y.add(29);		// 7
    	puntosInteresMapa0Y.add(32);		// 8
    	puntosInteresMapa0Y.add(35);		// 9
    	puntosInteresMapa0Y.add(38);		// 10
    	puntosInteresMapa0Y.add(41);		// 11
    }
    
    public AssetSetter(GamePanel gp)
    {
        this.gp = gp;
        timer = new Timer();
        map0PointsX();
        map0PointsY();
    }

    public void setObject()
    {
        boolean perm1 = true;
        boolean perm2 = true;
        boolean perm3 = true;
        boolean perm4 = true;
        
        int mapNum = 0;
        int i = 0;
        
        int[] position;

        position = getRandomEmptyPosition(mapNum);
        gp.obj[mapNum][i] = new OBJ_Door(gp);
        gp.obj[mapNum][i].worldX = position[0];
        gp.obj[mapNum][i].worldY = position[1];
        i++;

        position = getRandomEmptyPosition(mapNum);
        gp.obj[mapNum][i] = new OBJ_Door(gp);
        gp.obj[mapNum][i].worldX = position[0];
        gp.obj[mapNum][i].worldY = position[1];
        i++;
        
        // 1
        for (int j = 0; j < minAmmount; j++)
        {
            position = getRandomEmptyPosition(mapNum);
            gp.obj[mapNum][i] = new OBJ_Axe(gp);
            gp.obj[mapNum][i].worldX = position[0];
            gp.obj[mapNum][i].worldY = position[1];
            i++;
        }
        
        for (int j = 0; j < maxAmmount; j++)
        {
            if (perm1) 
            {
                perm1 = gp.rnum.nextBoolean();
            }
            
            if (perm1) 
            {
                position = getRandomEmptyPosition(mapNum);
                gp.obj[mapNum][i] = new OBJ_Axe(gp);
                gp.obj[mapNum][i].worldX = position[0];
                gp.obj[mapNum][i].worldY = position[1];
                i++;
            }
        }
        
        // 2
        for (int j = 0; j < minAmmount; j++) 
        {
            position = getRandomEmptyPosition(mapNum);
            gp.obj[mapNum][i] = new OBJ_Lantern(gp);
            gp.obj[mapNum][i].worldX = position[0];
            gp.obj[mapNum][i].worldY = position[1];
            i++;
        }
        
        for (int j = 0; j < maxAmmount; j++) 
        {
            if (perm2) 
            {
                perm2 = gp.rnum.nextBoolean();
            }
            
            if (perm2) 
            {
                position = getRandomEmptyPosition(mapNum);
                gp.obj[mapNum][i] = new OBJ_Lantern(gp);
                gp.obj[mapNum][i].worldX = position[0];
                gp.obj[mapNum][i].worldY = position[1];
                i++;
            }
        }
        
        // 3
        for (int j = 0; j < minAmmount; j++)
        {
            position = getRandomEmptyPosition(mapNum);
            gp.obj[mapNum][i] = new OBJ_Tent(gp);
            gp.obj[mapNum][i].worldX = position[0];
            gp.obj[mapNum][i].worldY = position[1];
            i++;
        }
        
        for (int j = 0; j < maxAmmount; j++) 
        {
            if (perm3)
            {
                perm3 = gp.rnum.nextBoolean();
            }
            
            if (perm3)
            {
                position = getRandomEmptyPosition(mapNum);
                gp.obj[mapNum][i] = new OBJ_Tent(gp);
                gp.obj[mapNum][i].worldX = position[0];
                gp.obj[mapNum][i].worldY = position[1];
                i++;
            }
        }
        
        // 4
        for (int j = 0; j < minAmmount; j++)
        {
            position = getRandomEmptyPosition(mapNum);
            gp.obj[mapNum][i] = new OBJ_Key(gp);
            gp.obj[mapNum][i].worldX = position[0];
            gp.obj[mapNum][i].worldY = position[1];
            i++;
        }
        
        for (int j = 0; j < maxAmmount; j++) 
        {
            if (perm4) 
            {
                perm4 = gp.rnum.nextBoolean();
            }
            
            if (perm4) 
            {
                position = getRandomEmptyPosition(mapNum);
                gp.obj[mapNum][i] = new OBJ_Key(gp);
                gp.obj[mapNum][i].worldX = position[0];
                gp.obj[mapNum][i].worldY = position[1];
                i++;
            }
        }

//        mapNum = 1;//adding object to second map
//        i=0;
//        gp.obj[mapNum][i] = new OBJ_Coin_Bronze(gp);
//        gp.obj[mapNum][i].worldX = gp.tileSize * 10;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 10;
//        i++;
//
//        mapNum = 2;
//        i = 0;
//        gp.obj[mapNum][i] = new OBJ_Chest(gp);
//        gp.obj[mapNum][i].setLoot(new OBJ_Pickaxe(gp));
//        gp.obj[mapNum][i].worldX = gp.tileSize * 40;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 41;
//        i++;
//        gp.obj[mapNum][i] = new OBJ_Chest(gp);
//        gp.obj[mapNum][i].setLoot(new OBJ_Potion_Red(gp));
//        gp.obj[mapNum][i].worldX = gp.tileSize * 13;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 16;
//        i++;
//        gp.obj[mapNum][i] = new OBJ_Chest(gp);
//        gp.obj[mapNum][i].setLoot(new OBJ_Potion_Red(gp));
//        gp.obj[mapNum][i].worldX = gp.tileSize * 26;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 34;
//        i++;
//        gp.obj[mapNum][i] = new OBJ_Chest(gp);
//        gp.obj[mapNum][i].setLoot(new OBJ_Potion_Red(gp));
//        gp.obj[mapNum][i].worldX = gp.tileSize * 27;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 15;
//        i++;
//        gp.obj[mapNum][i] = new OBJ_Door_Iron(gp);
//        gp.obj[mapNum][i].worldX = gp.tileSize * 18;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 23;
//        i++;
//
//        mapNum = 3;
//        i = 0;
//        gp.obj[mapNum][i] = new OBJ_Door_Iron(gp);
//        gp.obj[mapNum][i].worldX = gp.tileSize * 25;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 15;
//        i++;
//
//        gp.obj[mapNum][i] = new OBJ_BlueHeart(gp);
//        gp.obj[mapNum][i].worldX = gp.tileSize * 25;
//        gp.obj[mapNum][i].worldY = gp.tileSize * 8;
//        i++;
    }

//    public void setNPC()
//    {
//        int mapNum = 0;
//        int i = 0;
//
//        //MAP = 0
//        gp.npc[mapNum][i] = new NPC_OldMan(gp);
//        gp.npc[mapNum][i].worldX = gp.tileSize*21;
//        gp.npc[mapNum][i].worldY = gp.tileSize*21;
//        i++;
//
//        //MAP = 1
//        mapNum = 1;
//        i = 0;
//
//        gp.npc[mapNum][i] = new NPC_Merchant(gp);
//        gp.npc[mapNum][i].worldX = gp.tileSize*12;
//        gp.npc[mapNum][i].worldY = gp.tileSize*7;
//        i++;
//
//        mapNum = 2;
//        i = 0;
//
//        gp.npc[mapNum][i] = new NPC_BigRock(gp);
//        gp.npc[mapNum][i].worldX = gp.tileSize*20;
//        gp.npc[mapNum][i].worldY = gp.tileSize*25;
//        i++;
//        gp.npc[mapNum][i] = new NPC_BigRock(gp);
//        gp.npc[mapNum][i].worldX = gp.tileSize*11;
//        gp.npc[mapNum][i].worldY = gp.tileSize*18;
//        i++;
//        gp.npc[mapNum][i] = new NPC_BigRock(gp);
//        gp.npc[mapNum][i].worldX = gp.tileSize*23;
//        gp.npc[mapNum][i].worldY = gp.tileSize*14;
//        i++;
//
//    }
    
    public void setMonster()
    {
    	boolean perm1 = true;
    	boolean perm2 = true;
    	
    	int mapNum = 0;
        int i = 0;
        
        // 1
        
        for (int j = 0; j < minAmmount; j++) 
        {
        	gp.monster[mapNum][i] = new MON_GreenSlime(gp);
            gp.monster[mapNum][i].worldX = gp.obj[mapNum][0].worldX;
            gp.monster[mapNum][i].worldY = gp.obj[mapNum][0].worldY;
            i++;
            gp.totalMonstersCreated++;
        }
        
        for (int j = 0; j < maxAmmount; j++) 
        {
        	if(perm1)
    		{
    			perm1 = gp.rnum.nextBoolean();
    		}
        	
        	if (perm1) 
    		{    			
        		gp.monster[mapNum][i] = new MON_GreenSlime(gp);
                gp.monster[mapNum][i].worldX = gp.obj[mapNum][0].worldX;
                gp.monster[mapNum][i].worldY = gp.obj[mapNum][0].worldY;
                i++;
                gp.totalMonstersCreated++;
            } 
        }
        
        // 2
        
        for (int j = 0; j < minAmmount; j++) 
        {
        	gp.monster[mapNum][i] = new MON_RedSlime(gp);
            gp.monster[mapNum][i].worldX = gp.obj[mapNum][1].worldX;
            gp.monster[mapNum][i].worldY = gp.obj[mapNum][1].worldY;
            i++;  
            gp.totalMonstersCreated++;
        }
        
        for (int j = 0; j < maxAmmount; j++) 
        {
        	if(perm2)
    		{
    			perm1 = gp.rnum.nextBoolean();
    		}
        	
        	if (perm2) 
    		{    			
        		gp.monster[mapNum][i] = new MON_RedSlime(gp);
                gp.monster[mapNum][i].worldX = gp.obj[mapNum][1].worldX;
                gp.monster[mapNum][i].worldY = gp.obj[mapNum][1].worldY;
                i++;  
                gp.totalMonstersCreated++;
            } 
        }

//        gp.monster[mapNum][i] = new MON_Orc(gp);
//        gp.monster[mapNum][i].worldX = gp.tileSize*12;
//        gp.monster[mapNum][i].worldY = gp.tileSize*33;
//        i++;

//
//        mapNum = 2;
//        i = 0;
//
//        gp.monster[mapNum][i] = new MON_Bat(gp);
//        gp.monster[mapNum][i].worldX = gp.tileSize*34;
//        gp.monster[mapNum][i].worldY = gp.tileSize*39;
//        i++;
//
//        gp.monster[mapNum][i] = new MON_Bat(gp);
//        gp.monster[mapNum][i].worldX = gp.tileSize*36;
//        gp.monster[mapNum][i].worldY = gp.tileSize*25;
//        i++;
//
//        gp.monster[mapNum][i] = new MON_Bat(gp);
//        gp.monster[mapNum][i].worldX = gp.tileSize*39;
//        gp.monster[mapNum][i].worldY = gp.tileSize*26;
//        i++;
//
//        gp.monster[mapNum][i] = new MON_Bat(gp);
//        gp.monster[mapNum][i].worldX = gp.tileSize*28;
//        gp.monster[mapNum][i].worldY = gp.tileSize*11;
//        i++;
//
//        gp.monster[mapNum][i] = new MON_Bat(gp);
//        gp.monster[mapNum][i].worldX = gp.tileSize*10;
//        gp.monster[mapNum][i].worldY = gp.tileSize*19;
//        i++;
//
//        mapNum = 3;
//        i = 0;
//
//        if(Progress.skeletonLordDefeated == false)
//        {
//            gp.monster[mapNum][i] = new MON_SkeletonLord(gp);
//            gp.monster[mapNum][i].worldX = gp.tileSize*23;
//            gp.monster[mapNum][i].worldY = gp.tileSize*16;
//            i++;
//        }
    }
    
//    public void setInteractiveTile()
//    {
//        int mapNum = 0;
//        int i = 0;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,27,12);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,28,12);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,29,12);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,30,12);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,32,12);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,33,12);i++;
//
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,18,40);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,17,40);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,16,40);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,15,40);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,14,40);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,13,40);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,10,40);i++;
//
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,13,41);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,12,41);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,11,41);i++;
//        gp.iTile[mapNum][i] = new IT_DryTree(gp,10,41);i++;
//
//        mapNum = 2;
//        i = 0;
//
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,18,30);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,17,31);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,17,32);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,17,34);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,18,34);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,10,33);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,10,22);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,38,24);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,38,18);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,38,19);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,38,21);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,18,13);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,18,14);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,22,28);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,30,28);i++;
//        gp.iTile[mapNum][i] = new IT_DestructibleWall(gp,32,28);i++;
//
//        gp.iTile[mapNum][i] = new IT_MetalPlate(gp,20,22);i++;
//        gp.iTile[mapNum][i] = new IT_MetalPlate(gp,8,17);i++;
//        gp.iTile[mapNum][i] = new IT_MetalPlate(gp,39,31);i++;
//    }
}
