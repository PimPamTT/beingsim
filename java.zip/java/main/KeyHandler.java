package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.SQLException;

public class KeyHandler implements KeyListener {

    GamePanel gp;
    
    public boolean upPressed, downPressed, leftPressed, rightPressed, qPressed, ePressed, spacePressed;
    
    public int behavior1;
    public int behavior2;
    public int behavior3;
     
    public Form form1 = new Form();
    public Form form2 = new Form();
    
//    public boolean upPressed, downPressed, leftPressed,rightPressed,enterPressed,shotKeyPressed, spacePressed;
//    //DEBUG
//    public boolean showDebugText = false;
//    public boolean godModeOn = false;
//
    @Override
    public void keyTyped(KeyEvent e) {
    }

    public KeyHandler(GamePanel gp)
    {
        this.gp = gp;
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();

        // TITLE STATE
        if(gp.gameState == gp.titleState) 
        {
            try {
				titleState(code);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
        // PLAY STATE
        else if(gp.gameState == gp.playState)
        {
            playState(code);
        }
        else if(gp.gameState == gp.spectatorState)
        {
            spectatorState(code);
        }
        // PAUSE STATE
        else if(gp.gameState == gp.pauseState)
        {
            pauseState(code);
        }
//        //DIALOGUE STATE
//        else if(gp.gameState == gp.dialogueState || gp.gameState == gp.cutsceneState)
//        {
//            dialogueState(code);
//        }
//        // CHARACTER STATE
//        else if(gp.gameState == gp.characterState)
//        {
//            characterState(code);
//        }
//        // OPTIONS STATE
//        else if(gp.gameState == gp.optionsState)
//        {
//            optionsState(code);
//        }
//        // GAMEOVER STATE
//        else if(gp.gameState == gp.gameOverState)
//        {
//            gameOverState(code);
//        }
//        // TRADE STATE
//        else if(gp.gameState == gp.tradeState)
//        {
//            tradeState(code);
//        }
        // MAP STATE
        else if(gp.gameState == gp.mapState)
        {
            mapState(code);
        }
    }

    public void titleState(int code) throws SQLException
    {
        //MAIN MENU
        if (gp.ui.titleScreenState == 0) {
            if (code == KeyEvent.VK_W) {
                gp.ui.commandNum--;
                gp.playSE(21);
                if (gp.ui.commandNum < 0) {
                    gp.ui.commandNum = 1;
                }
            }
            if (code == KeyEvent.VK_S) {
                gp.ui.commandNum++;
                gp.playSE(21);
                if (gp.ui.commandNum > 1) {
                    gp.ui.commandNum = 0;
                }
            }
            if (code == KeyEvent.VK_ENTER) {
                if (gp.ui.commandNum == 0) {
                	gp.playSE(2);
                    gp.ui.titleScreenState = 1; // Character class selection screen
//                    gp.gameState = gp.playState;
                }
//                if (gp.ui.commandNum == 1) {
//                    //LOAD GAME
//                    gp.saveLoad.load();
//                    gp.gameState = gp.playState;
//                    gp.playMusic(0);
//                }
                if (gp.ui.commandNum == 1) {
                	gp.playSE(12);
                    System.exit(0);
                }
            }
        }
        //SECOND SCREEN // CHARACTER SELECTION
        else if (gp.ui.titleScreenState == 1) {
            if (code == KeyEvent.VK_W) {
                gp.ui.commandNum--;
                gp.playSE(21);
                if (gp.ui.commandNum < 0) {
                    gp.ui.commandNum = 9;
                }
            }
            if (code == KeyEvent.VK_S) {
                gp.ui.commandNum++;
                gp.playSE(21);
                if (gp.ui.commandNum >= 10) {
                    gp.ui.commandNum = 0;
                }
            }            
            if (code == KeyEvent.VK_ENTER) 
            {
            	form(form1);
                if (gp.ui.commandNum == 8) {
                	gp.playSE(12);
                	if(form1.count >= 1)
                	{
                		System.out.println(form1);
                		gp.dbManager.insertSpecies("Green Slime", gp.dbManager.getDietByName(form1.diet));
                		
                		behaviors(form1);
                		
                		gp.ui.titleScreenState = 2;
                		gp.ui.commandNum = 0;
                	}                	
                }
                if (gp.ui.commandNum == 9) {
                	gp.playSE(12);                	
                    gp.ui.titleScreenState = 0;   
                    gp.ui.commandNum = 0;
                    gp.restartDatabase();
                }
            }
        }              
        //THIRD SCREEN // CHARACTER SELECTION
        else if (gp.ui.titleScreenState == 2) {
        	if (code == KeyEvent.VK_W) {
                gp.ui.commandNum--;
                gp.playSE(21);
                if (gp.ui.commandNum < 0) {
                    gp.ui.commandNum = 9;
                }
            }
            if (code == KeyEvent.VK_S) {
                gp.ui.commandNum++;
                gp.playSE(21);
                if (gp.ui.commandNum >= 10) {
                    gp.ui.commandNum = 0;
                }
            }
            if (code == KeyEvent.VK_ENTER) {
            	form(form2);
                if (gp.ui.commandNum == 8) {
                	gp.playSE(12);
                	if(form2.count >= 1)
                	{
                		System.out.println(form2);
                		gp.dbManager.insertSpecies("Red Slime", gp.dbManager.getDietByName(form2.diet));
                		
                		behaviors(form2);
                		
                		gp.aSetter.setMonster();
                		gp.gameState = gp.playState;
                	}                	
                }
                if (gp.ui.commandNum == 9) {
                	gp.playSE(12);                	
                    gp.ui.titleScreenState = 0;   
                    gp.ui.commandNum = 0;
                    gp.restartDatabase();
                }
            }
        }
    }
    
    public void playState(int code)
    {
        if(code == KeyEvent.VK_W)
        {
            upPressed = true;
        }
        if(code == KeyEvent.VK_S)
        {
            downPressed = true;
        }
        if(code == KeyEvent.VK_A)
        {
            leftPressed = true;
        }
        if(code == KeyEvent.VK_D)
        {
            rightPressed = true;
        }
        if(code == KeyEvent.VK_SPACE)
        {
            spacePressed = true;
        }
        if(code == KeyEvent.VK_P)
        {
            gp.gameState = gp.pauseState;
        }
//        if(code == KeyEvent.VK_C)
//        {
//            gp.gameState = gp.characterState;
//        }
//        if(code == KeyEvent.VK_ENTER)
//        {
//            enterPressed = true;
//        }
//        if(code == KeyEvent.VK_F)
//        {
//            shotKeyPressed = true;
//        }
//        if(code == KeyEvent.VK_ESCAPE)
//        {
//            gp.gameState = gp.optionsState;
//        }
        if(code == KeyEvent.VK_M)
        {
            gp.gameState = gp.mapState;
        }
        if(code == KeyEvent.VK_X)
        {
            if(gp.map.miniMapOn == false)
            {
                gp.map.miniMapOn = true;
            }
            else
            {
                gp.map.miniMapOn = false;
            }
        }
//        if(code == KeyEvent.VK_SPACE)
//        {
//            spacePressed = true;
//        }
//
//        //DEBUG
//        
//        if(code == KeyEvent.VK_T)   //Debug Menu
//        {
//            if(showDebugText == false)
//            {
//                showDebugText = true;
//            }
//            else if(showDebugText == true)
//            {
//                showDebugText = false;
//            }
//        }
//        if(code == KeyEvent.VK_R)   //Refresh Map without restarting game // Save Map File : in IntellijIDE "Ctrl + F9", in Eclipce "Ctrl + S"
//        {
//            switch (gp.currentMap)
//            {
//                case 0: gp.tileM.loadMap("/maps/worldV3.txt",0); break;
//                case 1: gp.tileM.loadMap("/maps/interior01.txt",1); break;
//            }
//        }
//        if(code == KeyEvent.VK_G)   //Debug Menu
//        {titl
//            if(godModeOn == false)
//            {
//                godModeOn = true;
//            }
//            else if(godModeOn == true)
//            {
//                godModeOn = false;
//            }
//        }
        // Hasta aquí está el debug
    }
    
    public void spectatorState(int code)
    {
        if(code == KeyEvent.VK_Q)
        {
            qPressed = true;
        }
        if(code == KeyEvent.VK_E)
        {
            ePressed = true;
        }
        if(code == KeyEvent.VK_SPACE)
        {
            spacePressed = true;
        }
        if(code == KeyEvent.VK_P)
        {
            gp.gameState = gp.pauseState;
        }
        if(code == KeyEvent.VK_M)
        {
            gp.gameState = gp.mapState;
        }
        if(code == KeyEvent.VK_X)
        {
            if(gp.map.miniMapOn == false)
            {
                gp.map.miniMapOn = true;
            }
            else
            {
                gp.map.miniMapOn = false;
            }
        }
    }
    
    public void pauseState(int code)
    {
        if(code == KeyEvent.VK_ESCAPE)
        {
            gp.gameState = gp.playState;
        }
    }
//    public void dialogueState(int code)
//    {
//        if(code == KeyEvent.VK_ENTER)
//        {
//            enterPressed = true;
//        }
//    }
//    public void characterState(int code)
//    {
//        if(code == KeyEvent.VK_C)
//        {
//            gp.gameState = gp.playState;
//        }
//
//        if(code == KeyEvent.VK_ENTER)
//        {
//            gp.player.selectItem();
//        }
//        playerInventory(code);
//    }
//    public void optionsState(int code)
//    {
//        if(code == KeyEvent.VK_ESCAPE)
//        {
//            gp.gameState = gp.playState;
//        }
//        if(code == KeyEvent.VK_ENTER)
//        {
//            enterPressed = true;
//        }
//        int maxCommandNum = 0;
//        switch (gp.ui.subState)
//        {
//            case 0: maxCommandNum = 5; break;
//            case 3: maxCommandNum = 1; break;
//        }
//        if(code == KeyEvent.VK_W)
//        {
//            gp.ui.commandNum--;
//            gp.playSE(9);
//            if(gp.ui.commandNum < 0)
//            {
//                gp.ui.commandNum = maxCommandNum;
//            }
//        }
//        if(code == KeyEvent.VK_S)
//        {
//            gp.ui.commandNum++;
//            gp.playSE(9);
//            if(gp.ui.commandNum > maxCommandNum)
//            {
//                gp.ui.commandNum = 0;
//            }
//        }
//        if(code == KeyEvent.VK_A)
//        {
//            if(gp.ui.subState == 0)
//            {
//                if(gp.ui.commandNum == 1 && gp.music.volumeScale > 0) //music
//                {
//                    gp.music.volumeScale--;
//                    gp.music.checkVolume();  //check for music maybe a song is already being played, but you dont need it for SE, when set a sound checkVolume will be execute.
//                    gp.playSE(9);
//                }
//                if(gp.ui.commandNum == 2 && gp.se.volumeScale > 0) //SE
//                {
//                    gp.se.volumeScale--;
//                    gp.playSE(9);
//                }
//            }
//        }
//        if(code == KeyEvent.VK_D)
//        {
//            if(gp.ui.subState == 0)
//            {
//                if(gp.ui.commandNum == 1 && gp.music.volumeScale < 5) //music
//                {
//                    gp.music.volumeScale++;
//                    gp.music.checkVolume();
//                    gp.playSE(9);
//                }
//                if(gp.ui.commandNum == 2 && gp.se.volumeScale < 5) //SE
//                {
//                    gp.se.volumeScale++;
//                    gp.playSE(9);
//                }
//            }
//        }
//    }
//    public void gameOverState(int code)
//    {
//        if(code == KeyEvent.VK_W)
//        {
//            gp.ui.commandNum--;
//            if(gp.ui.commandNum < 0)
//            {
//                gp.ui.commandNum = 1;
//            }
//            gp.playSE(9);
//        }
//        if(code == KeyEvent.VK_S)
//        {
//            gp.ui.commandNum++;
//            if(gp.ui.commandNum > 1)
//            {
//                gp.ui.commandNum = 0;
//            }
//            gp.playSE(9);
//        }
//        if(code == KeyEvent.VK_ENTER)
//        {
//            if(gp.ui.commandNum == 0) //RETRY, reset position, life, mana, monsters, npcs...
//            {
//                gp.gameState = gp.playState;
//                gp.resetGame(false);
//                gp.playMusic(0);
//            }
//            else if(gp.ui.commandNum == 1) //QUIT, reset everything
//            {
//                gp.ui.titleScreenState = 0;
//                gp.gameState = gp.titleState;
//                gp.resetGame(true);
//            }
//        }
//    }
//    public void tradeState(int code)
//    {
//        if(code == KeyEvent.VK_ENTER)
//        {
//            enterPressed = true;
//        }
//        if(gp.ui.subState == 0)
//        {
//            if(code == KeyEvent.VK_W)
//            {
//                gp.ui.commandNum--;
//                if(gp.ui.commandNum < 0)
//                {
//                    gp.ui.commandNum = 2;
//                }
//                gp.playSE(9);
//            }
//            if(code == KeyEvent.VK_S)
//            {
//                gp.ui.commandNum++;
//                if(gp.ui.commandNum > 2)
//                {
//                    gp.ui.commandNum = 0;
//                }
//                gp.playSE(9);
//            }
//        }
//        if(gp.ui.subState == 1)
//        {
//            npcInventory(code);
//            if(code == KeyEvent.VK_ESCAPE)
//            {
//                gp.ui.subState = 0;
//            }
//        }
//        if(gp.ui.subState == 2)
//        {
//            playerInventory(code);
//            if(code == KeyEvent.VK_ESCAPE)
//            {
//                gp.ui.subState = 0;
//            }
//        }
//    }
    public void mapState(int code)
    {
       if(code == KeyEvent.VK_M)
       {
           gp.gameState = gp.playState;
       }
    }
//    public void playerInventory(int code)
//    {
//        if(code == KeyEvent.VK_W)
//        {
//            if(gp.ui.playerSlotRow != 0)
//            {
//                gp.ui.playerSlotRow--;
//                gp.playSE(9);   //cursor.wav
//            }
//        }
//        if(code == KeyEvent.VK_A)
//        {
//            if(gp.ui.playerSlotCol !=0)
//            {
//                gp.ui.playerSlotCol--;
//                gp.playSE(9);
//            }
//        }
//        if(code == KeyEvent.VK_S)
//        {
//            if(gp.ui.playerSlotRow != 3)
//            {
//                gp.ui.playerSlotRow++;
//                gp.playSE(9);
//            }
//        }
//        if(code == KeyEvent.VK_D)
//        {
//            if(gp.ui.playerSlotCol != 4)
//            {
//                gp.ui.playerSlotCol++;
//                gp.playSE(9);
//            }
//        }
//    }
//    public void npcInventory(int code)
//    {
//        if(code == KeyEvent.VK_W)
//        {
//            if(gp.ui.npcSlotRow != 0)
//            {
//                gp.ui.npcSlotRow--;
//                gp.playSE(9);   //cursor.wav
//            }
//        }
//        if(code == KeyEvent.VK_A)
//        {
//            if(gp.ui.npcSlotCol !=0)
//            {
//                gp.ui.npcSlotCol--;
//                gp.playSE(9);
//            }
//        }
//        if(code == KeyEvent.VK_S)
//        {
//            if(gp.ui.npcSlotRow != 3)
//            {
//                gp.ui.npcSlotRow++;
//                gp.playSE(9);
//            }
//        }
//        if(code == KeyEvent.VK_D)
//        {
//            if(gp.ui.npcSlotCol != 4)
//            {
//                gp.ui.npcSlotCol++;
//                gp.playSE(9);
//            }
//        }
//    }
//
   @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();

        if(code == KeyEvent.VK_W)
        {
            upPressed = false;
        }
        if(code == KeyEvent.VK_S)
        {
            downPressed = false;
        }
        if(code == KeyEvent.VK_A)
        {
            leftPressed = false;
        }
        if(code == KeyEvent.VK_D)
        {
            rightPressed = false;
        }
//        if(code == KeyEvent.VK_F)
//        {
//            shotKeyPressed = false;
//        }
//        if(code == KeyEvent.VK_ENTER)
//        {
//            enterPressed = false;
//        }
//        if(code == KeyEvent.VK_SPACE)
//        {
//            spacePressed = false;
//        }
    }
   
   	public void form(Form pForm) throws SQLException
   	{
    	if (gp.ui.commandNum == 0) 
    	{
    		gp.playSE(2);
    		pForm.addBehavior("aggresive");
    		
//            if (!aggresive && count < 3) 
//            {
//                aggresive = true;
//                count++ ;
//                System.out.println("Si se puede:" + count + ".");	                    
//                if(count == 1)
//                {
//                	behavior1 = gp.dbManager.getBehaviorByName("aggresive");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior1 + ".");
//                }   
//                if(count == 2)
//                {
//                	behavior2 = gp.dbManager.getBehaviorByName("aggresive");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior2 + ".");
//                } 
//                if(count == 3)
//                {
//                	behavior3 = gp.dbManager.getBehaviorByName("aggresive");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior3 + ".");
//                } 
//            } 
//            else if (aggresive) 
//            {
//            	// Lo mas seguro que lo tenga que poner a null o vacio
//                aggresive = false;
//                count--;
//                System.out.println("Si se puede:" + count + ".");
//            } 
    	}            	
    	if (gp.ui.commandNum == 1) 
    	{
            gp.playSE(2);
            pForm.addBehavior("calm");
            
//            if (!calm && count < 3) 
//            {
//                calm = true;
//                count++;
//                System.out.println("Si se puede:" + count + ".");
//                if(count == 1)
//                {
//                	behavior1 = gp.dbManager.getBehaviorByName("calm");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior1 + ".");
//                }   
//                if(count == 2)
//                {
//                	behavior2 = gp.dbManager.getBehaviorByName("calm");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior2 + ".");
//                } 
//                if(count == 3)
//                {
//                	behavior3 = gp.dbManager.getBehaviorByName("calm");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior3 + ".");
//                }  
//            } 
//            else if (calm) 
//            {
//                calm = false;
//                count--;
//                System.out.println("Si se puede:" + count + ".");
//            } 
        }
        if (gp.ui.commandNum == 2) 
        {
            gp.playSE(2);
            pForm.addBehavior("smart");
//            if (!smart && count < 3) 
//            {
//                smart = true;
//                count++;
//                System.out.println("Si se puede:" + count + ".");
//                if(count == 1)
//                {
//                	behavior1 = gp.dbManager.getBehaviorByName("smart");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior1 + ".");
//                }   
//                if(count == 2)
//                {
//                	behavior2 = gp.dbManager.getBehaviorByName("smart");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior2 + ".");
//                } 
//                if(count == 3)
//                {
//                	behavior3 = gp.dbManager.getBehaviorByName("smart");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior3 + ".");
//                } 
//            } 
//            else if (smart) 
//            {
//                smart = false;
//                count--;
//                System.out.println("Si se puede:" + count + ".");
//            } 
        }            	
        if (gp.ui.commandNum == 3) 
        {
            gp.playSE(2);
            pForm.addBehavior("dumb");
//            if (!dumb && count < 3) 
//            {
//            	dumb = true;
//                count++;
//                System.out.println("Si se puede:" + count + ".");
//                if(count == 1)
//                {
//                	behavior1 = gp.dbManager.getBehaviorByName("dumb");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior1 + ".");
//                }   
//                if(count == 2)
//                {
//                	behavior2 = gp.dbManager.getBehaviorByName("dumb");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior2 + ".");
//                } 
//                if(count == 3)
//                {
//                	behavior3 = gp.dbManager.getBehaviorByName("dumb");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior3 + ".");
//                } 
//            } 
//            else if (dumb) 
//            {
//            	dumb = false;
//                count--;
//                System.out.println("Si se puede:" + count + ".");
//            } 
        }       	
        if (gp.ui.commandNum == 4) 
        {
            gp.playSE(2);
            pForm.addBehavior("farsighted");
//            if (!farsighted && count < 3) 
//            {
//            	farsighted = true;
//                count++;
//                System.out.println("Si se puede:" + count + ".");
//                if(count == 1)
//                {
//                	behavior1 = gp.dbManager.getBehaviorByName("farsighted");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior1 + ".");
//                }   
//                if(count == 2)
//                {
//                	behavior2 = gp.dbManager.getBehaviorByName("farsighted");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior2 + ".");
//                } 
//                if(count == 3)
//                {
//                	behavior3 = gp.dbManager.getBehaviorByName("farsighted");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior3 + ".");
//                } 
//            } 
//            else if (farsighted) 
//            {
//            	farsighted = false;
//                count--;
//                System.out.println("Si se puede:" + count + ".");
//            } 
        }
        if (gp.ui.commandNum == 5) 
        {
            gp.playSE(2);
            pForm.addBehavior("careless");
//            if (!careless && count < 3) 
//            {
//            	careless = true;
//                count++;
//                System.out.println("Si se puede:" + count + ".");
//                if(count == 1)
//                {
//                	behavior1 = gp.dbManager.getBehaviorByName("careless");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior1 + ".");
//                }   
//                if(count == 2)
//                {
//                	behavior2 = gp.dbManager.getBehaviorByName("careless");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior2 + ".");
//                } 
//                if(count == 3)
//                {
//                	behavior3 = gp.dbManager.getBehaviorByName("careless");
//                	System.out.println("Esto funca y es:" + count + "; el behavior es:" + behavior3 + ".");
//                } 
//            } 
//            else if (careless) 
//            {
//            	careless = false;
//                count--;
//                System.out.println("Si se puede:" + count + ".");
//            } 
        }
        if (gp.ui.commandNum == 6) 
        {
        	gp.playSE(2);
        	pForm.addDiet("carnivore");
//			  if(carnivore == false && herbivore == true)
//			  {
//			  	carnivore = true;
//			  	herbivore = false;
//			  	diet = gp.dbManager.getDietByName("carnivore");
//			  	System.out.println("La diet es:" + diet + ".");
//			  }
//			  else if(carnivore == true && herbivore == false)
//			  {
//			  	carnivore = false;
//			  	herbivore = true;
//			  	diet = gp.dbManager.getDietByName("herbivore");
//			  	System.out.println("La diet es:" + diet + ".");
//		      }
		  }
		  if (gp.ui.commandNum == 7) 
		  {
			  gp.playSE(2);
	          pForm.addDiet("herbivore");
//		      if(herbivore == false && carnivore == true)
//		      {
//				 herbivore = true;
//				 carnivore = false;
//				 diet = gp.dbManager.getDietByName("herbivore");
//				 System.out.println("La diet es:" + diet + ".");
//			  }
//			  else if(herbivore == true && carnivore == false)
//			  {				  	
//				 herbivore = false;
//			  	 carnivore = true;
//			  	 diet = gp.dbManager.getDietByName("carnivore");
//			  	 System.out.println("La diet es:" + diet + ".");
//		      }
	  	}
   	}
   	
   	public void behaviors(Form pForm) throws SQLException
   	{
   		
   		behavior1 = 0;
   		behavior2 = 0;
   		behavior3 = 0;
   		
   		if(pForm.count == 1) 
   		{
   			behavior1 = gp.dbManager.getBehaviorByName(pForm.behaviors.get(0)); 		
   		}
   		if(pForm.count == 2) 
   		{
   			behavior1 = gp.dbManager.getBehaviorByName(pForm.behaviors.get(0));
   			behavior2 = gp.dbManager.getBehaviorByName(pForm.behaviors.get(1)); 
   		}
   		if(pForm.count == 3) 
   		{
   			behavior1 = gp.dbManager.getBehaviorByName(pForm.behaviors.get(0));
   			behavior2 = gp.dbManager.getBehaviorByName(pForm.behaviors.get(1)); 	
   			behavior3 = gp.dbManager.getBehaviorByName(pForm.behaviors.get(2));
   		}
   		
   		   		
   		if(gp.ui.titleScreenState == 1)
   		{
   			if(pForm.count == 1)
   			{
   				gp.dbManager.insertSpeciesBehaviors(1, behavior1);
   				System.out.println("Registro 1 realizado con exito.");
   				
//   				if(behavior1 == 0 && behavior2 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior3);
//   	    			System.out.println("Registro 3 que en este caso es 1 realizado con exito.");
//   				}
//   				if(behavior1 == 0 && behavior3 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior2);
//   	    			System.out.println("Registro 2 que en este caso es 1 realizado con exito.");
//   				}
//   				if(behavior2 == 0 && behavior3 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior1);
//   	    			System.out.println("Registro 1 que en este caso es 1 realizado con exito.");
//   				}
   			}
   			if(pForm.count == 2)
   			{
   				gp.dbManager.insertSpeciesBehaviors(1, behavior1);
   				System.out.println("Registro 1 realizado con exito.");
   				gp.dbManager.insertSpeciesBehaviors(1, behavior2);
   				System.out.println("Registro 2 realizado con exito.");
//   				if(behavior1 == 0)
//   				{
   					
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior2);
//   	    			System.out.println("Registro 2 que en este caso es 1 realizado con exito.");
//   	    			gp.dbManager.insertSpeciesBehaviors(1, behavior3);
//   	    			System.out.println("Registro 3 que en este caso es 2 realizado con exito.");
// 					}
//   				if(behavior2 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior1);
//   	    			System.out.println("Registro 1 que en este caso está bien realizado con exito.");
//      					    			gp.dbManager.insertSpeciesBehaviors(1, behavior3);
//   	    			System.out.println("Registro 3 que en este caso es 2 realizado con exito.");
//   				}
//   				if(behavior3 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior1);
//   	    			System.out.println("Registro 1 que en este caso está bien realizado con exito.");
//   	    			gp.dbManager.insertSpeciesBehaviors(1, behavior2);
//   	    			System.out.println("Registro 2 que en este caso está bien realizado con exito.");
//   				}
   			}
   			if(pForm.count == 3)
   			{
   				gp.dbManager.insertSpeciesBehaviors(1, behavior1);
   				System.out.println("Registro 1 realizado con exito.");
   				gp.dbManager.insertSpeciesBehaviors(1, behavior2);
   				System.out.println("Registro 2 realizado con exito.");
   				gp.dbManager.insertSpeciesBehaviors(1, behavior3);
   				System.out.println("Registro 3 realizado con exito.");
   			}		        
   		}
   		
   		if(gp.ui.titleScreenState == 2)
   		{
   			if(pForm.count == 1)
   			{
   				gp.dbManager.insertSpeciesBehaviors(2, behavior1);
   				System.out.println("Registro 1 realizado con exito.");
   				
//   				if(behavior1 == 0 && behavior2 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior3);
//   	    			System.out.println("Registro 3 que en este caso es 1 realizado con exito.");
//   				}
//   				if(behavior1 == 0 && behavior3 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior2);
//   	    			System.out.println("Registro 2 que en este caso es 1 realizado con exito.");
//   				}
//   				if(behavior2 == 0 && behavior3 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior1);
//   	    			System.out.println("Registro 1 que en este caso es 1 realizado con exito.");
//   				}
   			}
   			if(pForm.count == 2)
   			{
   				gp.dbManager.insertSpeciesBehaviors(2, behavior1);
   				System.out.println("Registro 1 realizado con exito.");
   				gp.dbManager.insertSpeciesBehaviors(2, behavior2);
   				System.out.println("Registro 2 realizado con exito.");
//   				if(behavior1 == 0)
//   				{
   					
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior2);
//   	    			System.out.println("Registro 2 que en este caso es 1 realizado con exito.");
//   	    			gp.dbManager.insertSpeciesBehaviors(1, behavior3);
//   	    			System.out.println("Registro 3 que en este caso es 2 realizado con exito.");
// 					}
//   				if(behavior2 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior1);
//   	    			System.out.println("Registro 1 que en este caso está bien realizado con exito.");
//      					    			gp.dbManager.insertSpeciesBehaviors(1, behavior3);
//   	    			System.out.println("Registro 3 que en este caso es 2 realizado con exito.");
//   				}
//   				if(behavior3 == 0)
//   				{
//   					gp.dbManager.insertSpeciesBehaviors(1, behavior1);
//   	    			System.out.println("Registro 1 que en este caso está bien realizado con exito.");
//   	    			gp.dbManager.insertSpeciesBehaviors(1, behavior2);
//   	    			System.out.println("Registro 2 que en este caso está bien realizado con exito.");
//   				}
   			}
   			if(pForm.count == 3)
   			{
   				gp.dbManager.insertSpeciesBehaviors(2, behavior1);
   				System.out.println("Registro 1 realizado con exito.");
   				gp.dbManager.insertSpeciesBehaviors(2, behavior2);
   				System.out.println("Registro 2 realizado con exito.");
   				gp.dbManager.insertSpeciesBehaviors(2, behavior3);
   				System.out.println("Registro 3 realizado con exito.");
   			}		        
   		}
   	}
}
