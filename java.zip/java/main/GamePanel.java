package main;

import ai.PathFinder;
import db.DatabaseManager;
//import data.SaveLoad;
//import entity.Player;
//import environment.EnvironmentManager;
import tile.Map;
import tile.TileManager;
//import tile_interactive.InteractiveTile;

import javax.swing.JPanel;

import entity.Entity;
import entity.Timer;
//import monster.MON_GreenSlime;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Comparator;
import java.util.Comparator;
import java.util.Random;


@SuppressWarnings("serial")
public class GamePanel extends JPanel implements Runnable
{	
	public Random rnum = new Random();
	int numEntity = rnum.nextInt(20) + 50;
	int numObject = rnum.nextInt(20) + 50;
	
	public DatabaseManager dbManager;								// Lo utilizamos para acceder a la base de datos
	
    // CONFIGURACIÓN DE PANTALLA
    final int originalTileSize = 16; // 16*16  tile. default
    final int scale = 3; // 16*3 scale

    public final int tileSize = originalTileSize * scale; 			// 48*48 tile // los hacemos public por lo usamos en la clase Player
    public final int maxScreenCol = 20; 							// 4:3 
    public final int maxScreenRow = 12;
    public final int screenWidth = tileSize * maxScreenCol;  		//48*20 = 960 pixels
    public final int screenHeight = tileSize * maxScreenRow;  		//48*12 = 576 pixels  // TAMAÑO DE LA PANTALLA

    // CONFIGURACIÓN DEL MUNDO
    public int maxWorldCol;											// Máximo número de columnas del mundo
    public int maxWorldRow;			
    public final int worldWidth = tileSize + maxWorldCol;
    public final int worldHeight = tileSize + maxWorldRow;
    
    // Máximo número de filas del mundo
    public final int maxMap = 10;									// Máximo número de mapas que puede tener el juego (10)
    public int currentMap = 0;										// Partimos del mapa 0

    // PARA PANTALLA COMPLETA
    int screenWidth2 = screenWidth;									// Guardamos la resolución para pantalla completa
    int screenHeight2 = screenHeight;
    BufferedImage tempScreen;										// Usa una pantalla temporal
    Graphics2D g2;													// Usamos un objeto graphics2D para hacer todas las impresiones
    public boolean fullScreenOn = false;							// Por defecto partimos de que no está seleccionada la pantalla completa

    // FPS
    int FPS = 60;													// Marcamos 60 frames como obejtivo para el renderizado del juego

    // SISTEMA
    public TileManager tileM = new TileManager(this);				// Creamos un objeto de TileManager
    public Entity camera = new Entity(this); 						// Creamos una camera
      
    public Timer timer = new Timer(240);
    
    public KeyHandler keyH = new KeyHandler(this);					// Creamos un objeto para manejar el teclado  
//    public EventHandler eHandler = new EventHandler(this);			// Creamos un objeto para gestinador de eventos
    Sound music = new Sound(); 										// Creamos 2 objetos diferentes para efectos de Sonido y Música. Es mejor tener dos objetos distintos
    Sound se = new Sound();											// Objeto para efectos de sonido
    public CollisionChecker cChecker = new CollisionChecker(this);	// Creamos un objeto colisionador
    public AssetSetter  aSetter = new AssetSetter(this);			// Creamos un objeto que añade objetos en el mundo
    public UI ui = new UI(this);									// Creamos un objeto de tipo UI
//    Config config = new Config(this);								// Creamos un objeto de tipo configuración
    public PathFinder pFinder = new PathFinder(this);				// Creamos un objeto para usar los path finders
//    EnvironmentManager eManager = new EnvironmentManager(this);     //
    Map map = new Map(this);									    // Creamos un objeto de tipo mapa
//    SaveLoad saveLoad = new SaveLoad(this);							// Creamos un objeto para guardar
//    public EntityGenerator eGenerator = new EntityGenerator(this);	// Creamos un objeto para crear cameraes
//    public CutsceneManager csManager = new CutsceneManager(this);	// Creamos un objeto para crear cinemática para el jefe
    Thread gameThread;											    // Creamos un objeto de tipo hilo

//    // ENTIDADES Y OBJETOS
//    public Player player = new Player(this,keyH);							// Creamos el objeto player
    public Entity obj[][] = new Entity[maxMap][numObject]; 						// Mostramos 10 objetos a la vez
//    public Entity npc[][] = new Entity[maxMap][10];							// Mostramos 10 cameraes a la vez
    public Entity monster[][] = new Entity[maxMap][numEntity];					// Mostramos 10 monstruos
    public int totalMonstersCreated = 0;									    // Variable para identificar los monstruos creados 		
//    public InteractiveTile iTile[][] = new InteractiveTile[maxMap][50];		// Generamos 10 inteactive Tiles
//    public Entity projectile[][] = new Entity[maxMap][20]; 					// Generamos los proyectiles que son 10 cameraes
//    public ArrayList<Entity> particleList = new ArrayList<>();				// Se generan una array de partículas
    ArrayList<Entity> entityList = new ArrayList<>();						// Generamos un array de cameraes
    
    // GENERAMOS ESTADOS PARA EL JUEGO
    public int gameState;						// Variable que guarda el estado del juego
    public final int titleState = 0;			// Pantalla inicial (Título)
    public final int playState = 1;				// Pantalla de juego
    public final int spectatorState = 2;		// Pantalla de juego
    public final int pauseState = 3;			// Juego en pausa
//    public final int dialogueState = 3;			// Juego en dálogo
//    public final int characterState = 4;		// Pantalla donde se elige el personaje
//    public final int optionsState = 5;			// Pantalla de las opciones
//    public final int gameOverState = 6;			// Pantalla de Game over
//    public final int transitionState = 7;		// Transiciones
//    public final int tradeState = 8;			// Estamos en la tienda
//    public final int sleepState = 9;			// Pantalla de dormir
    public final int mapState = 4;				// Pantalla mostrando el mapa
//    public final int cutsceneState = 11;		// Pantalla en cut secene (Tiene una cinemática)

    // OTROS
//    public boolean bossBattleOn = false;		// Activar la batalla con el Jefe final

    // ÁREA - se usa principalmente para gestion de sonido y reseteo
//    public int currentArea;						// Guardamos el área
//    public int nextArea;						// Estalecemos la siguiente área
//    public final int outside = 50;				// Area en el exterior
//    public final int indoor = 51;				// Area interior
//    public final int dungeon = 52;				// Área mazmorra

    public int currentIndex = 0;
    boolean perm = true;
    
    public GamePanel(DatabaseManager dbManager) // constructor
    {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight)); 		// Tamaño del panel
        this.setBackground(Color.black);										// Fondo del panel de color negro
        this.setDoubleBuffered(true); 											// mejorar el rendimiento de renderizado del juego
        this.addKeyListener(keyH);												// Lanzamos el keylistener
        this.setFocusable(true);												// Activamos que tenga el foco
        this.dbManager = dbManager;
             
        camera.worldX = 20 * tileSize;
        camera.worldY = 20 * tileSize;
        camera.screenX = screenWidth/2 - (tileSize/2);
        camera.screenY = screenHeight/2- (tileSize/2);
                	
    }
   
    	
    public void setupGame()					// Se llama a esta función desde la clse main
    {
       aSetter.setObject();				// Cargamos los objetos en el array correspondiente
       // aSetter.setNPC();					// Cargamos los NPC en el array correspondiente
//       aSetter.setMonster();				// Cargamos los Montruos (enemigos) en el array correspondiente
       // aSetter.setInteractiveTile();		// Cargamos los objetois interactivos en el array correspondiente
       // eManager.setup();					// Configuramos el eManager

        gameState = titleState;				// Partimnos de la pantalla de título
        //FOR FULLSCREEN
        tempScreen = new BufferedImage(screenWidth,screenHeight,BufferedImage.TYPE_INT_ARGB); 		// instanciamos la pantalla temporal (de color negro)
        g2 = (Graphics2D) tempScreen.getGraphics(); 												// g2 apunta al tempScreen. g2 dibujará en esta tempScreen la imagen almacenada en buffer.
//        if(fullScreenOn == true)																	// Si se seleccionó la configuración de fullScreen 
//        {
//            setFullScreen();																		// Activa pantalla completa (función)
//        }
    }
//    public void resetGame(boolean restart)		// Función para resetear el juego (se llama de dos maneras, para hacerlo parcial o total)
//    {
//        stopMusic();					// Paramos la música
//        currentArea = outside;			// Pasamos al estado outside
//        removeTempEntity();			    // Borramos todas las cameraes temporales
//        bossBattleOn = false;			// Indicamos que 
//        player.setDefaultPositions();	// Ponemos la posición inicial del player
//        player.restoreStatus();			// restauramos su estado
//        aSetter.setMonster();			// Establecemos los monstruos
//        aSetter.setNPC();				// Establecemos los NPC
//        player.resetCounter();			// resetemos los contadores del jugador
//
//        if(restart == true)					// Si la variable restart esta a true
//        {
//            player.setDefaultValues();		// cargamos lo valores 
//            aSetter.setObject();			// Creamos los objetos
//            aSetter.setInteractiveTile();	// Los objetos inteactivas
//            eManager.lighting.resetDay();	// Resetamos la luz
//        }
//
//    }
//    public void setFullScreen()				// Función para gestionar que sea a pantalla completa
//    {
//        // OBTENER DISPOSITIVO DE PANTALLA LOCAL
//        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();		// Nos traemos las variables del entorno
//        GraphicsDevice gd = ge.getDefaultScreenDevice();								// y el disposivo gráfico
//        gd.setFullScreenWindow(Main.window);											// Activamos la pantalla completa
//
//        // OBTENER LA ANCHURA Y LA ALTURA DE LA PANTALLA COMPLETA
//        screenWidth2 = Main.window.getWidth();											// Guardamos la variables de tamaño del mundo de pantalla completa (ancho)
//        screenHeight2 = Main.window.getHeight();										// y alto
//    }

	public void startGameThread()		// Función para lanzar el Game Loop				
    {
        gameThread = new Thread(this);			// Creamos un hilo
        gameThread.start(); 					// Ejecuta la función run
    }

    @Override
    public void run()
    {
        double drawInterval = 1000000000/FPS;	// Sacamos lo que tarda un frame en nanosegundos
        double delta = 0;						// El delsta es cero
        long lastTime = System.nanoTime();		// Nos traemos el timpo actual en nanosegundos
        long currentTime;						// Variable para actualizar el timpo
        
        //long timer = 0;						// Esta variable podemos usarlas para identificar el número de Frame que es capaz de mostrar el juego
        //int drawCount = 0;

        while(gameThread != null)				// Loop del juego
        {
            currentTime = System.nanoTime();						// Cogemos el timpo actual
            delta += (currentTime - lastTime) / drawInterval;		// Identificamos el delta e el que estamos 
            //timer += currentTime - lastTime;						// Esto es para identificar el timer para identificar los frames que se pueden ver
            lastTime = currentTime;									// Guardamos este tiempo en la variable lastTime
            if(delta >= 1)											// Si hemos completado un frame 
            {	
                update();											// Actualizamos los personajes
                
                /*repaint(); comentado para pantalla completa*/
                drawToTempScreen(); 								// PARA LA PANTALLA COMPLETA - Dibujar todo en la imagen almacenada
                drawToScreen();     								// PARA LA PANTALLA COMPLETA - Dibujar la imagen almacenada en la memoria intermedia en la pantalla
                delta--;											// Ponemos delta a cero;
                //drawCount++;										// Se ha cumplido un frame, sumamos uno al contador
            }
            
            // MOSTRAR LOS FPS QUE ES CAPAZ DE SACAR EL JUEGO EN LA CONSOLA
            /*if(timer >= 1000000000)
            {
                System.out.println("FPS:" + drawCount);
                drawCount = 0;
                timer = 0;
            }*/
        }
    }

    public void update()
    {

    	
    	if(gameState == playState)
    	{
        	timer.update();
        	
        	if(timer.isTriggered())
        	{
        		updateMonster();
        	}
    		
    		if(keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true || keyH.rightPressed == true || keyH.spacePressed == true)
            {
    	        if(keyH.upPressed == true)
    	        {
    	        	camera.worldY -= 4;
    	        }
    	        else if(keyH.downPressed == true)
    	        {                                                                 
    	        	camera.worldY += 4;                                        
    	        }                                                                 
    	        else if(keyH.leftPressed == true)                                 
    	        {
    	        	 camera.worldX -= 4;
    	        }
    	        else if(keyH.rightPressed == true)
    	        {
    	        	 camera.worldX += 4;
    	        }
    	        else if(keyH.spacePressed == true)
    	        {
    	        	gameState = spectatorState;
    	        	keyH.spacePressed = false;
    	        }
            } 
    		
    		moveEntity();
    	}   	
    	
    	// Controlar que ya no quedan más bichos activos para cerrar la aplicación
    	
    	
    	if(gameState == spectatorState)
    	{
        	timer.update();
        	
        	if(timer.isTriggered())
        	{
        		updateMonster();
        	}
    		
    		if(keyH.qPressed == true || keyH.ePressed == true || keyH.spacePressed == true)
            {
    	        if(keyH.qPressed == true)												// Miramos si la tecla q está pulsada
    	        {
    	        	keyH.qPressed = false;												// Desactivamos la detección de la tecla Q
    	        		
    	        	if(currentIndex == 0)												// Si estamos en la posición 0
    	        	{
    	        		currentIndex = totalMonstersCreated-1;							// Nos ponemos al final de los monstruos creados 
    	        		
    	        	}
    	        	else
    	        	{
    	        		currentIndex--;													// si no restamos uno
    	        	}   
    	        	
    	        	if (monster[currentMap][currentIndex].active == false) 
        			{
        				do
	        			{
	        				currentIndex--;
	        			}	        			
	        			while(monster[currentMap][currentIndex].active == false);
        			}	
    	        	
//	        		if(monster[currentMap][currentIndex] == null)						// si es null
//	        		{	        			
//	        			do
//	        			{
//	        				currentIndex--;												// Nos movemos hasta que encontramos 1 que no sea null
//	        			}	        			
//	        			while(monster[currentMap][currentIndex] == null);
//	        			
//	        			if (monster[currentMap][currentIndex].active == false) 
//	        			{
//	        				do
//		        			{
//		        				currentIndex--;
//		        			}	        			
//		        			while(monster[currentMap][currentIndex].active == false);
//	        			}	        			
//	        		} 	        		
    	        }
    	        else if(keyH.ePressed == true)
    	        {             
    	        	keyH.ePressed = false;
    	        	
    	        	if(currentIndex == totalMonstersCreated-1)
    	        	{
    	        		currentIndex = 0;
    	        	}
    	        	else
    	        	{
    	        		currentIndex++;
    	        	}                  
	        		
    	        	if (monster[currentMap][currentIndex].active == false) 
        			{
        				do
	        			{
        					currentIndex++;	 
        					if(currentIndex == totalMonstersCreated-1)
            	        	{
            	        		currentIndex = 0;
            	        	}        					 
	        			}	        			
	        			while(monster[currentMap][currentIndex].active == false);
        			}
    	        	
//    	        	if(monster[currentMap][currentIndex] == null)
//	        		{
//	        			do
//	        			{
//	        				currentIndex++;
//	        				
//	        	        	if(currentIndex >= numEntity-1)
//	        	        	{
//	        	        		currentIndex = 0;
//	        	        	}
//	        			}
//	        			while(monster[currentMap][currentIndex] == null);
//	        			
//	        			if (monster[currentMap][currentIndex].active == false) 
//	        			{
//	        				do
//		        			{
//	        					currentIndex++;	  
//		        			}	        			
//		        			while(monster[currentMap][currentIndex].active == false);
//	        			}
//	        			
//	        		}
//    	        	else
//    	        	{
//    	        		if (monster[currentMap][currentIndex].active == false) 
//	        			{
//	        				do
//		        			{
//	        					currentIndex++;	  
//		        			}	        			
//		        			while(monster[currentMap][currentIndex].active == false);
//	        			}
//
//    	        	}
//    	        	
    	        }  
    	        else if(keyH.spacePressed == true)
    	        {
    	        	 gameState = playState;
    	        	 keyH.spacePressed = false;
    	        }
            } 
    		
    		moveEntity();
    	} 
//        if(gameState == playState)		// Si estamos en la pantalla de juego
//        {
//            // PLAYER
//            player.update();			// Actualizamos el player
//
//            // NPC
//            for(int i = 0; i < npc[1].length; i++)  // [1] usamos la segunda dimensión para el bucle.
//            {
//                if(npc[currentMap][i] != null)		// Si el NPC no es null
//                {
//                    npc[currentMap][i].update();	// lo actualizamos
//                }
//            }
//
        
//
//            // PROJECTILE										
//            for(int i = 0; i < projectile[1].length; i++)			// Recorremos todos los proyectiles
//            {
//                if(projectile[currentMap][i] != null)				// Si no es null
//                {
//                    if(projectile[currentMap][i].alive == true)		// Si está vivo
//                    {
//                        projectile[currentMap][i].update();			// Lo actualizamos
//                    }
//                    if(projectile[currentMap][i].alive == false)	// Si no está vivo 
//                    {
//                        projectile[currentMap][i] = null;			// Lo pasamos a null
//                    }
//                }
//            }
//
//            // PARTICLE
//            for(int i = 0; i < particleList.size(); i++)			// Recorremos todas las partículas
//            {
//                if(particleList.get(i)!= null)						// Si no es null
//                {
//                    if(particleList.get(i).alive == true)			// Si está vivo 
//                    {			
//                        particleList.get(i).update();				// Lo actualizamos
//                    }
//                    if(particleList.get(i).alive == false)			// Si no está vivo
//                    {
//                        particleList.remove(i);						// Se borra de la lista
//                    }
//                }
//            }
//
//            // INTERACTIVE TILE
//            for(int i = 0; i < iTile[1].length; i++)				// recorremos todos los interactive tiles
//            {
//                if(iTile[currentMap][i] != null)					// Si no está vacío
//                {
//                    iTile[currentMap][i].update();					// Lo actualizamos
//                }
//            }
//
//            eManager.update();										// Actualizamos el eManager
//        }
//
        if(gameState == pauseState)									// Si es pause no hacemos nada
        {
            //nothing, just pause screen
        }
    }
    
    // PARA PANTALLA COMPLETA (PRIMERO DIBUJAR EN PANTALLA TEMPORAL EN LUGAR DE JPANEL)
    public void drawToTempScreen()
    {
        //DEBUG
//        long drawStart = 0;											// Tenemos una varible que marca el drawstart
//        if(keyH.showDebugText == true)								// Se se ha pulsado la tecla para hacer debug
//        {
//            drawStart = System.nanoTime();							// Guardamos el tiempo en nanosegundos de este momento
//        }

        // SI ESTAMOS EN LA PANTALLA DE TITULO
        if(gameState == titleState)
        {
            ui.draw(g2);											// Dibujamos el UI
        }
        // PANTALLA DE MAPA
        else if(gameState == mapState)								// Si estamos en la pantalla del mapa
        {	
            map.drawFullMapScreen(g2);								// Pintamos el mapa a pantalla completa
        }
        // PARA EL RESTO
        else
        {
            //TILE
            tileM.draw(g2);											// Dibujamos el mapa

//            // INTERACTIVE TILE
//            for(int i = 0; i < iTile[1].length; i++)				// Dibujamos los inteactive
//            {
//                if(iTile[currentMap][i] != null)
//                {
//                    iTile[currentMap][i].draw(g2);
//                }
//            }
//
//            // AÑADIMOS EL PLAYER A LA LISTA DE ENTIDADES
//            entityList.add(player);
//
//            // AÑADIMOS LOS NPCS
//            for(int i = 0; i < npc[1].length; i++)
//            {
//                if(npc[currentMap][i] != null)
//                {
//                    entityList.add(npc[currentMap][i]);
//                }
//            }
//
            // AÑADIMOS LOS OBJETOS
            for(int i = 0; i < obj[1].length; i++)
            {
                if(obj[currentMap][i] != null)
                {
                    entityList.add(obj[currentMap][i]);
                }
            }

            // AÑADIMOS LOS MONSTERS
            for(int i = 0; i < monster[1].length; i++)
            {
                if(monster[currentMap][i] != null && monster[currentMap][i].active == true)
                {
                	entityList.add(monster[currentMap][i]);
                    
                    if(gameState == spectatorState)
                    {
                    	if (i == currentIndex) {
                    		camera.worldX = monster[currentMap][currentIndex].worldX;
                            camera.worldY = monster[currentMap][currentIndex].worldY;
                    	}                    	                 	
                    }
                }
            }
//
//            // AÑADIMOS LOS PROJECTILES
//            for(int i = 0; i < projectile[1].length; i++)
//            {
//                if(projectile[currentMap][i] != null)
//                {
//                    entityList.add(projectile[currentMap][i]);
//                }
//            }
//
//            // AÑADIMOS LAS PARTICULAS
//            for(int i = 0; i < particleList.size(); i++)
//            {
//                if(particleList.get(i) != null)
//                {
//                    entityList.add(particleList.get(i));
//                }
//            }

            // ORDENAMOS LA ENTITY LIST 
            Collections.sort(entityList, new Comparator<Entity>() {
                @Override
                public int compare(Entity e1, Entity e2) {
                    int result = Integer.compare(e1.worldY, e2.worldY);   // result returns : (x=y : 0, x>y : >0, x<y : <0)
                    return result;
                }
            });

            // DIBUJAR LAS ENTIDADES
            for(int i = 0; i < entityList.size(); i++)
            {
                entityList.get(i).draw(g2);
            }

            // LIMPIAMOS LA ENTITY LIST
            entityList.clear();

//            // PINTAMOS EL ENTORNO
//            eManager.draw(g2);
//
            // PINTAMOS MINI MAP
            map.drawMiniMap(g2);
//
//            // PINTAMOS LA CUTSCENE
//            csManager.draw(g2);
//
            // PINTAMOS UI
            ui.draw(g2);

            //DEBUG

//            if(keyH.showDebugText == true)								// Si tenemos la tecla de debug pulsada
//            {
//                long drawEnd = System.nanoTime();						// Tomamos el tiempo actual en nanosegundos
//                long passed = drawEnd - drawStart;						// Resta los nanosegundos para imprimir todo
//
//                g2.setFont(new Font("Arial", Font.PLAIN,20));			// Font Arial, tamañio 20
//                g2.setColor(Color.white);								// Color blanco
//                int x = 10;												// 10, 400
//                int y = 400;
//                int lineHeight = 20;									// tamaño de cada linea de texto
//
//                g2.drawString("WorldX " + player.worldX,x,y);			// Pintamos en pantalla WorldX WorldY, Col, Row, Map, tiempo y modo God.  
//                y+= lineHeight;
//                g2.drawString("WorldY " + player.worldY,x,y);
//                y+= lineHeight;
//                g2.drawString("Col " + (player.worldX + player.solidArea.x) / tileSize,x,y);
//                y+= lineHeight;
//                g2.drawString("Row " + (player.worldY + player.solidArea.y) / tileSize,x,y);
//                y+= lineHeight;
//                g2.drawString("Map " + currentMap,x,y);
//                y+= lineHeight;
//                g2.drawString("Draw time: " + passed,x,y);
//                y+= lineHeight;
//                g2.drawString("God Mode: " + keyH.godModeOn, x, y);
//
//            }
        }
    }
    
    public void drawToScreen()												// Función para pasar la pantalla 
    {
        Graphics g = getGraphics();											// Nos traemos el Gráfico actual del objetoi
        g.drawImage(tempScreen, 0, 0,screenWidth2,screenHeight2,null);		// Cargamos la pantalla temporal en el objeto gráfico
        g.dispose();														// Lo pinta,mos. 
    }
    
    public void playMusic(int i)		// Función para para que se ponga la música
    {
        music.setFile(i);				// Cargamos el fichero
        music.play();					// Hacemos play
        music.loop();				    // Lo ponemos en modo repetición
    }
    
    public void stopMusic()				
    {
        music.stop();					// Paramos la música
    }
    
    public void playSE(int i) 			// Función para los effectos de sonido, no necesitan repertirse
    {
        se.setFile(i);					// Cargamos el fichero
        se.play();						// lo hacemos sonar
    }
//    public void changeArea()			// Cambios de área
//    {
//        if(nextArea != currentArea)		// Si next area es distinta de la current área
//        {
//            stopMusic();				// Paramos la música
//
//            if(nextArea == outside)		// Si estamos en outside
//            {
//                playMusic(0);			// Ponemos la música 0
//            }
//            if(nextArea == indoor)		// Si es indoor
//            {
//                playMusic(18);			// Ponemos la música 18
//            }
//            if(nextArea == dungeon)		// Si estamos en la mazmorra
//            {
//                playMusic(19);			// Ponemos la música 19
//            }
//            aSetter.setNPC(); 			// Restablecer para en el rompecabezas de la mazmorra piedras atascadas.
//        }
//
//        currentArea = nextArea;			// Actualizamos el área actual con la siguiente 
//        aSetter.setMonster();			// Restablecemos los monstruos
//    }
//    
//    public void removeTempEntity()		// Borramos los objetos temporales de los mapas
//    {
//        for(int mapNum = 0; mapNum < maxMap; mapNum++)							// Recorremos todos los mapas
//        {
//            for(int i = 0; i < obj[1].length; i++)								// Por cada mapa recorremos todos los objetos
//            {
//                if(obj[mapNum][i] != null && obj[mapNum][i].temp == true)		// Si es null o es temporal 
//                {
//                    obj[mapNum][i] = null;									 	// Poner a null
//                }
//            }
//        }
//    }
    
    public void moveEntity()
    {
    	// MONSTER
        for(int i = 0; i < monster[1].length; i++)			// Recorremos todos los monstruos
        {
            if(monster[currentMap][i] != null && monster[currentMap][i].active == true)				// Si el monstruo del mapa actual no es null 
            {
                if(monster[currentMap][i].alive == true && monster[currentMap][i].dying == false)		// Si está vivo y no está muriendo
                {
                    monster[currentMap][i].update();		// Lo actualizamos
                }
                if(monster[currentMap][i].alive == false)	// Si esta muerto
                {
                    monster[currentMap][i].checkDrop(); 	// cuando el monstruo muere, se comprueba su caída
                    monster[currentMap][i] = null;			// lo pone a null
                }
            }
        }
    }
    
    public void updateMonster()
    {
    	if(perm)
    	{
	    	for(int i = 0; i < monster[1].length; i++)			// Recorremos todos los monstruos
	        {
	    		if(monster[currentMap][i+1] == null)
	    		{
	    			perm = false;
	    		}
	    		
	    		if(monster[currentMap][i].active == false)
	    		{
	    			monster[currentMap][i].active = true;
	    			break;
	    		}	    		
	        }
    	}
    }
    
    public void restartDatabase() throws SQLException
    {
    	dbManager.closeConnection();
    	
    	System.out.println("Base de datos cerrada.");
    	
    	dbManager = new DatabaseManager("jdbc:sqlite::memory:");

        dbManager.createTables();
        
        String[] dietColumns = {"name"};
        Object[] dietValues = {"carnivore"};
        dbManager.insert("Diet", dietColumns, dietValues);            

        dietValues = new Object[] {"herbivore"};
        dbManager.insert("Diet", dietColumns, dietValues);
        
        String[] behaviorsColumns = {"name"};
        Object[] behaviorsValues = {"aggresive"}; 
        dbManager.insert("Behaviors", behaviorsColumns, behaviorsValues);

        behaviorsValues = new Object[] {"calm"};
        dbManager.insert("Behaviors", behaviorsColumns, behaviorsValues);
        
        behaviorsValues = new Object[] {"smart"};
        dbManager.insert("Behaviors", behaviorsColumns, behaviorsValues);
        
        behaviorsValues = new Object[] {"dumb"};
        dbManager.insert("Behaviors", behaviorsColumns, behaviorsValues);
        
        behaviorsValues = new Object[] {"farsighted"};
        dbManager.insert("Behaviors", behaviorsColumns, behaviorsValues);
        
        behaviorsValues = new Object[] {"careless"};
        dbManager.insert("Behaviors", behaviorsColumns, behaviorsValues);        	
        
        System.out.println("Base de datos y tablas creadas con éxito.");
        
        keyH.form1 = new Form();
        keyH.form2 = new Form();
    }
}
